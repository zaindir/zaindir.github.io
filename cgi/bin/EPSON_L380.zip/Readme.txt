Click Run-ME ...
and just click OK <<<



